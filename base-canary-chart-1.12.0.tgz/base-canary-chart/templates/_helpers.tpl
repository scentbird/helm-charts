{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "base-canary-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "base-canary-chart.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "base-canary-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "base-canary-chart.labels" -}}
app: {{ include "base-canary-chart.name" . }}
chart: {{ include "base-canary-chart.chart" . }}
release: {{ .Release.Name }}
heritage: {{ .Release.Service }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "base-canary-chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "base-canary-chart.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{/*
The canary strategy.

trafficRouting follows the data path, not just `enabled`. Argo Rollouts' nginx
router looks the stable Ingress up by name on every SetWeight and returns an
error when it is missing, which stops the rollout on its first canary step - so
the block is emitted only in the modes that actually render an Ingress.

Every rendered HTTPRoute is handed to the Gateway API plugin, which rewrites the
weights its backendRefs carry. That needs canaryServices: without the stable and
canary Services the route has a single backendRef and there is nothing to weight.
The plugin is not part of Argo Rollouts - it is installed into the controller
separately, and until it is, a Rollout naming it will not progress.

Istio's own VirtualService is not an option here. On Istio 1.29 a VirtualService
cannot attach to a Gateway API Gateway at all, by any referencable name.

Under `both` the route and the Ingress are driven at once, by the plugin and the
nginx router respectively - Argo Rollouts allows several providers together.
That is what makes `both` safe to sit in: whichever share of traffic DNS has
already moved to the gateway is weighted the same as the share still on nginx.
Without canaryServices it is still a trap, because then the route keeps its one
backendRef to the Service that selects stable and canary pods alike, and the
gateway share ignores the weight while the rollout reports success.

With no HTTPRoute and no Ingress - every service here that has no ingress block -
there is no traffic router at all and the canary splits by replica count:
`setWeight` moves pods rather than traffic. It is approximate, and more so with
dynamicStableScale off, where stable keeps every replica: setWeight 10 sends
about 10/110 of requests and the closing setWeight 100 about half.
*/}}
{{- define "base-canary-chart.canaryStrategy" -}}
{{- if .Values.canary.enabled -}}
{{- $default := .Values.ingress.default | default dict -}}
{{- $mode := $default.mode | default .Values.routeMode | default "ingress" -}}
{{- $nginx := and $default.enabled (or (eq $mode "ingress") (eq $mode "both")) -}}
{{- /* The routes httproute.yaml actually renders, in the same order. */ -}}
{{- $routes := list -}}
{{- if .Values.canary.canaryServices -}}
{{- range $name, $entry := .Values.ingress -}}
{{- if and $entry $entry.enabled -}}
{{- $m := $entry.mode | default $.Values.routeMode | default "ingress" -}}
{{- if or (eq $m "httproute") (eq $m "both") -}}
{{- $routes = append $routes (printf "%s-%s" (include "base-canary-chart.fullname" $) $name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
strategy:
  canary:
    {{- if or $nginx $routes }}
    trafficRouting:
      {{- if $nginx }}
      nginx:
        stableIngress: {{ include "base-canary-chart.fullname" . }}-default
      {{- end }}
      {{- if $routes }}
      plugins:
        argoproj-labs/gatewayAPI:
          httpRoutes:
          {{- range $routes }}
            - name: {{ . }}
          {{- end }}
      {{- end }}
    {{- end }}
    dynamicStableScale: {{ .Values.canary.dynamicStableScale }}
    abortScaleDownDelaySeconds: {{ .Values.canary.abortScaleDownDelaySeconds }}
    maxSurge: {{ .Values.canary.maxSurge | quote }}
    maxUnavailable: {{ .Values.canary.maxUnavailable | quote }}
    {{- if .Values.canary.canaryServices }}
    stableService: {{ include "base-canary-chart.fullname" . }}-stable
    canaryService: {{ include "base-canary-chart.fullname" . }}-canary
    {{- end }}
    steps: {{ toYaml .Values.canary.steps | nindent 6 }}
{{- else -}}
strategy: {}
{{- end -}}
{{- end -}}


{{/*
Get KubeVersion removing pre-release information.
*/}}
{{- define "base-canary-chart.kubeVersion" -}}
  {{- default .Capabilities.KubeVersion.Version (regexFind "v[0-9]+\\.[0-9]+\\.[0-9]+" .Capabilities.KubeVersion.Version) -}}
{{- end -}}

{{/*
Return the appropriate apiVersion for ingress.
*/}}
{{- define "base-canary-chart.ingress.apiVersion" -}}
  {{- if and (.Capabilities.APIVersions.Has "networking.k8s.io/v1") (semverCompare ">= 1.19.x" (include "base-canary-chart.kubeVersion" .)) -}}
      {{- print "networking.k8s.io/v1" -}}
  {{- else if .Capabilities.APIVersions.Has "networking.k8s.io/v1beta1" -}}
    {{- print "networking.k8s.io/v1beta1" -}}
  {{- else -}}
    {{- print "extensions/v1beta1" -}}
  {{- end -}}
{{- end -}}

{{/*
Return if ingress is stable.
*/}}
{{- define "base-canary-chart.ingress.isStable" -}}
  {{- eq (include "base-canary-chart.ingress.apiVersion" .) "networking.k8s.io/v1" -}}
{{- end -}}

{{/*
Return if ingress supports ingressClassName.
*/}}
{{- define "base-canary-chart.ingress.supportsIngressClassName" -}}
  {{- or (eq (include "base-canary-chart.ingress.isStable" .) "true") (and (eq (include "base-canary-chart.ingress.apiVersion" .) "networking.k8s.io/v1beta1") (semverCompare ">= 1.18.x" (include "base-canary-chart.kubeVersion" .))) -}}
{{- end -}}

{{/*
Return if ingress supports pathType.
*/}}
{{- define "base-canary-chart.ingress.supportsPathType" -}}
  {{- or (eq (include "base-canary-chart.ingress.isStable" .) "true") (and (eq (include "base-canary-chart.ingress.apiVersion" .) "networking.k8s.io/v1beta1") (semverCompare ">= 1.18.x" (include "base-canary-chart.kubeVersion" .))) -}}
{{- end -}}

{{/*
Gateway that replaces a given ingress class. The three gateways mirror the
three nginx controllers one for one.
*/}}
{{- define "base-canary-chart.route.gateway" -}}
{{- if eq . "internal-nginx" -}}internal
{{- else if eq . "net-nginx" -}}net
{{- else -}}public
{{- end -}}
{{- end -}}

{{/*
Listener to bind to. The internal gateway terminates TLS itself from two
wildcards, so a route has to name the one matching its zone; without a
sectionName it would also attach to the plaintext listener and serve there
instead of redirecting. In front of public and net an ALB terminates TLS, so
there is nothing to choose.
Takes a dict with `class` and `host`.
*/}}
{{- define "base-canary-chart.route.section" -}}
{{- if eq .class "internal-nginx" -}}
{{- if hasSuffix ".scentbird.com" .host -}}https-com{{- else -}}https-net{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Route timeout. ingress-nginx defaults to 60s where Envoy defaults to 15s, so it
is always set explicitly. Note the semantics differ: proxy-read-timeout is an
inactivity timer, timeouts.request is a hard wall clock over the whole
exchange, so a streaming endpoint needs a value large enough for the whole
stream and not just for a gap in it.
*/}}
{{- define "base-canary-chart.route.timeout" -}}
{{- $a := .annotations | default dict -}}
{{- index $a "nginx.ingress.kubernetes.io/proxy-read-timeout" | default "60" -}}
{{- end -}}
