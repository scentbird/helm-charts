{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "base-canary-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "base-canary-chart.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "base-canary-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "base-canary-chart.labels" -}}
app: {{ include "base-canary-chart.name" . }}
chart: {{ include "base-canary-chart.chart" . }}
release: {{ .Release.Name }}
heritage: {{ .Release.Service }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "base-canary-chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "base-canary-chart.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{- define "base-canary-chart.canaryStrategy" -}}
{{- if .Values.canary.enabled -}}
strategy:
  canary:
    {{- if .Values.ingress.default.enabled }}
    trafficRouting:
      nginx:
        stableIngress: {{ include "base-canary-chart.fullname" . }}-default
    {{- end }}
    dynamicStableScale: {{ .Values.canary.dynamicStableScale }}
    abortScaleDownDelaySeconds: {{ .Values.canary.abortScaleDownDelaySeconds }}
    maxSurge: {{ .Values.canary.maxSurge | quote }}
    maxUnavailable: {{ .Values.canary.maxUnavailable | quote }}
    {{- if .Values.canary.canaryServices }}
    stableService: {{ include "base-canary-chart.fullname" . }}-stable
    canaryService: {{ include "base-canary-chart.fullname" . }}-canary
    {{- end }}
    steps: {{ toYaml .Values.canary.steps | nindent 6 }}
{{- else -}}
strategy: {}
{{- end -}}
{{- end -}}


{{/*
Get KubeVersion removing pre-release information.
*/}}
{{- define "base-canary-chart.kubeVersion" -}}
  {{- default .Capabilities.KubeVersion.Version (regexFind "v[0-9]+\\.[0-9]+\\.[0-9]+" .Capabilities.KubeVersion.Version) -}}
{{- end -}}

{{/*
Return the appropriate apiVersion for ingress.
*/}}
{{- define "base-canary-chart.ingress.apiVersion" -}}
  {{- if and (.Capabilities.APIVersions.Has "networking.k8s.io/v1") (semverCompare ">= 1.19.x" (include "base-canary-chart.kubeVersion" .)) -}}
      {{- print "networking.k8s.io/v1" -}}
  {{- else if .Capabilities.APIVersions.Has "networking.k8s.io/v1beta1" -}}
    {{- print "networking.k8s.io/v1beta1" -}}
  {{- else -}}
    {{- print "extensions/v1beta1" -}}
  {{- end -}}
{{- end -}}

{{/*
Return if ingress is stable.
*/}}
{{- define "base-canary-chart.ingress.isStable" -}}
  {{- eq (include "base-canary-chart.ingress.apiVersion" .) "networking.k8s.io/v1" -}}
{{- end -}}

{{/*
Return if ingress supports ingressClassName.
*/}}
{{- define "base-canary-chart.ingress.supportsIngressClassName" -}}
  {{- or (eq (include "base-canary-chart.ingress.isStable" .) "true") (and (eq (include "base-canary-chart.ingress.apiVersion" .) "networking.k8s.io/v1beta1") (semverCompare ">= 1.18.x" (include "base-canary-chart.kubeVersion" .))) -}}
{{- end -}}

{{/*
Return if ingress supports pathType.
*/}}
{{- define "base-canary-chart.ingress.supportsPathType" -}}
  {{- or (eq (include "base-canary-chart.ingress.isStable" .) "true") (and (eq (include "base-canary-chart.ingress.apiVersion" .) "networking.k8s.io/v1beta1") (semverCompare ">= 1.18.x" (include "base-canary-chart.kubeVersion" .))) -}}
{{- end -}}
