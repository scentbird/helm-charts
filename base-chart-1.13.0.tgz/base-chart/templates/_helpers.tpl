{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "base-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "base-chart.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "base-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "base-chart.labels" -}}
app: {{ include "base-chart.name" . }}
chart: {{ include "base-chart.chart" . }}
release: {{ .Release.Name }}
heritage: {{ .Release.Service }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "base-chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "base-chart.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Get KubeVersion removing pre-release information.
*/}}
{{- define "base-chart.kubeVersion" -}}
  {{- default .Capabilities.KubeVersion.Version (regexFind "v[0-9]+\\.[0-9]+\\.[0-9]+" .Capabilities.KubeVersion.Version) -}}
{{- end -}}

{{/*
Return the appropriate apiVersion for ingress.
*/}}
{{- define "base-chart.ingress.apiVersion" -}}
  {{- if and (.Capabilities.APIVersions.Has "networking.k8s.io/v1") (semverCompare ">= 1.19.x" (include "base-chart.kubeVersion" .)) -}}
      {{- print "networking.k8s.io/v1" -}}
  {{- else if .Capabilities.APIVersions.Has "networking.k8s.io/v1beta1" -}}
    {{- print "networking.k8s.io/v1beta1" -}}
  {{- else -}}
    {{- print "extensions/v1beta1" -}}
  {{- end -}}
{{- end -}}

{{/*
Return if ingress is stable.
*/}}
{{- define "base-chart.ingress.isStable" -}}
  {{- eq (include "base-chart.ingress.apiVersion" .) "networking.k8s.io/v1" -}}
{{- end -}}

{{/*
Return if ingress supports ingressClassName.
*/}}
{{- define "base-chart.ingress.supportsIngressClassName" -}}
  {{- or (eq (include "base-chart.ingress.isStable" .) "true") (and (eq (include "base-chart.ingress.apiVersion" .) "networking.k8s.io/v1beta1") (semverCompare ">= 1.18.x" (include "base-chart.kubeVersion" .))) -}}
{{- end -}}

{{/*
Return if ingress supports pathType.
*/}}
{{- define "base-chart.ingress.supportsPathType" -}}
  {{- or (eq (include "base-chart.ingress.isStable" .) "true") (and (eq (include "base-chart.ingress.apiVersion" .) "networking.k8s.io/v1beta1") (semverCompare ">= 1.18.x" (include "base-chart.kubeVersion" .))) -}}
{{- end -}}

{{/*
Gateway that replaces a given ingress class. The three gateways mirror the
three nginx controllers one for one.
*/}}
{{- define "base-chart.route.gateway" -}}
{{- if eq . "internal-nginx" -}}internal
{{- else if eq . "net-nginx" -}}net
{{- else -}}public
{{- end -}}
{{- end -}}

{{/*
Listener to bind to. The internal gateway terminates TLS itself from two
wildcards, so a route has to name the one matching its zone; without a
sectionName it would also attach to the plaintext listener and serve there
instead of redirecting. In front of public and net an ALB terminates TLS, so
there is nothing to choose.
Takes a dict with `class` and `host`.
*/}}
{{- define "base-chart.route.section" -}}
{{- if eq .class "internal-nginx" -}}
{{- if hasSuffix ".scentbird.com" .host -}}https-com{{- else -}}https-net{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Route timeout. ingress-nginx defaults to 60s where Envoy defaults to 15s, so it
is always set explicitly. Note the semantics differ: proxy-read-timeout is an
inactivity timer, timeouts.request is a hard wall clock over the whole
exchange, so a streaming endpoint needs a value large enough for the whole
stream and not just for a gap in it.

`routeTimeout` on the entry, in seconds, overrides the annotation for the
route alone. It is for the case where no finite wall clock fits: an SSE or MCP
stream, which nginx keeps open on a 3600s idle timer, needs `routeTimeout: 0`
(no timeout) on Envoy. The Ingress keeps its annotation untouched.
Takes a dict with `ingress` (the entry).
*/}}
{{- define "base-chart.route.timeout" -}}
{{- if hasKey .ingress "routeTimeout" -}}
{{- .ingress.routeTimeout -}}
{{- else -}}
{{- $a := .ingress.annotations | default dict -}}
{{- index $a "nginx.ingress.kubernetes.io/proxy-read-timeout" | default "60" -}}
{{- end -}}
{{- end -}}
